﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// added extra system to write to a new file
using System.IO;

namespace Moonbase
{
    public partial class FormMain : Form
    {
        private string currentPosition; // keeps track of current position in GUI/form
        public FormMain()
        {
            InitializeComponent();

        }

        // save location of user to a log file
        private void LogPosition (string position)
        {
            // print the date and time with text "Moved to " + position of user
            string logEntry = $"{DateTime.Now}: Moved to {position}{Environment.NewLine}"; // .NewLine ensures that the log entry ends with a newline, making the log file easier to read.
            // uses System.IO to write to a file / create a file
            File.AppendAllText("user_location_log.txt",  logEntry);
        }

        // Function to update the form
        private void UpdateForm (string roomName, string roomDescription, Image background)
        {
            currentPosition = roomName;
            this.BackgroundImage = background;
            textBox1.Text = roomName; // Update Room name
            textBox2.Text = roomDescription; // Update Room Description
            LogPosition(roomName);
            
        }

        private void BTNnorth_Click(object sender, EventArgs e)
        {
            UpdateForm("Meeting Hall", "Inside, the Meeting Hall is bustling with activity. Pomeranians in their tiny space suits sit attentively at the central command table, which is equipped with state-of-the-art holographic displays and control panels. The walls are adorned with interactive screens showcasing cosmic charts, planetary data, and the latest findings from their explorations. Every detail in the Meeting Hall is designed to inspire collaboration and innovation among the Pomeranian crew, making it the perfect place for brainstorming new ideas and planning their next " +
                "big adventure in the cosmos.", Properties.Resources.northMoonBase_MeetingRoom); // Properties.Resources...fileName is how you access files in the Resources of the project
        }

        private void BTNeast_Click(object sender, EventArgs e)
        {
            UpdateForm("Storage Room", "Welcome to the Storage Room, the meticulously organized hub of our moonbase where all essential supplies and equipment are kept. This room is a treasure trove of technological wonders and provisions, carefully arranged on illuminated shelves and compartments. In the center of the room stands 2 Pomeranian astronauts, ready to embark on their next mission. They are busy inspecting equipment and checking inventory. Their tiny paws and curious expressions add a charming touch to the " +
                "high-tech environment.", Properties.Resources.eastMoonBase_StorageRoom);
        }

        private void BTNsouth_Click(object sender, EventArgs e)
        {
            UpdateForm("Spacewalk ~ Near Base", "Oops! It looks like our adventurous Pomeranian astronaut took an unexpected detour while heading \"south\" and ended up in the vast expanse of space! Caught in the act of exploring the unknown, our brave little pup floats gracefully in the void, with the backdrop of a magnificent galaxy swirling with vibrant colors. Despite the surprise, our Pomeranian astronaut remains calm and collected, ready to take on the wonders and challenges of " +
                "deep space.", Properties.Resources.southMoonBase_SpaceWalk);
        }

        private void BTNwest_Click(object sender, EventArgs e)
        {
            UpdateForm("Westside Cafe", "As you step into the cafe, you're greeted by the aroma of freshly baked goods and the sight of colorful donuts and pastries adorning the shelves. The walls are lined with an array of delectable delights, from fluffy cupcakes to tantalizing tarts, all carefully crafted to bring a smile to your face. In the center of the cafe, three adorable Pomeranian astronauts stand proudly, dressed in their vibrant space suits. Their joyful expressions and wagging tails add an extra touch of cheer to the already lively atmosphere. They serve as the cafe's unofficial mascots, always ready to welcome new guests " +
                "with a friendly bark.", Properties.Resources.westMoonBase_Cafe);
        }
    }
}
